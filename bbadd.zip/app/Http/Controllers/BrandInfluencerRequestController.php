<?php

namespace App\Http\Controllers;

use App\Models\BrandInfluencerRequest;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BrandInfluencerRequestController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show()
    {
        //
    }

    public function edit()
    {
        //
    }

    public function update(Request $request)
    {
        //
    }

    public function destroy()
    {
        //
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Apply;
use App\Http\Controllers\Controller;
use App\Models\CheckApply;
use Illuminate\Http\Request;

class ApplyController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show()
    {
        //
    }

    public function edit()
    {
        //
    }

    public function update(Request $request)
    {
        //
    }

    public function destroy()
    {
        //
    }
}

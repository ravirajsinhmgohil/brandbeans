<style>
    *,
*::before,
*::after {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.gallery {
  column-count: 4;
  --webkit-column-count: 4;
  --moz-column-count: 4;
  gap: 1rem;
  padding: 4rem;
}

.image img {
  height: auto;
  width: 100%;
}

/* Responsive-ness for different screen-sizes */
@media screen and (max-width: 810px) {
  .gallery {
    column-count: 3;
    --webkit-column-count: 3;
    --moz-column-count: 3;
  }
}

@media screen and (max-width: 500px) {
  .gallery {
    column-count: 2;
    --webkit-column-count: 2;
    --moz-column-count: 2;
  }
}

@media screen and (max-width: 400px) {
  .gallery {
    column-count: 1;
    --webkit-column-count: 1;
    --moz-column-count: 1;
  }
}

</style>


<section class="gallery">
    <div class="image">
      @foreach ($collection as $item) 
        <img src="{{url('categoryimg')}}/{{$item->iconPath}}" alt="image" />
      @endforeach
    </div>
  </section>